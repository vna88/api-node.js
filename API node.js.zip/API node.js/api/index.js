const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

const postsRoutes = require('./routes/posts');
const commentsRoutes = require('./routes/comments');

app.use('/posts', postsRoutes);
app.use('/comments', commentsRoutes);

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
