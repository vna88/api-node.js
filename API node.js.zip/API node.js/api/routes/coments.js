const express = require('express');
const router = express.Router();

let comments = [];

router.get('/', (req, res) => {
    res.json(comments);
  });

  router.post('/:postId', (req, res) => {
    const { postId } = req.params;
    const { text } = req.body;
    const newComment = {
      id: comments.length + 1,
      postId: parseInt(postId),
      text,
    };
    comments.push(newComment);
  res.status(201).json(newComment);
});

module.exports = router;